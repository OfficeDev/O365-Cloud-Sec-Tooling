﻿# -----------------------------------------------------------------------------
#  CollectAndScoreSecurityData.ps1
#
#   o Iterarte through configurations and calculate security score
#
#   Copyright (c) Microsoft Corporation - 2015
# -----------------------------------------------------------------------------

# pass in an optional configuration file for the master information to run the collector
#   Usage: 
#     powershell -File CollectAndScoreSecurityData.ps1 
#   OR 
#     powershell -File CollectAndScoreSecurityData.ps1 -config NewConfigFile

 param (
    [string] $config ="https://o365securescore.azurewebsites.net/downloads/ConfigForSecurityScore.txt"       
 )

Start-Transcript -Path .\securescoreruntimetranscript.txt
Write-Host "Configuration comes from: $config";
if ($config -eq $null) {
    Write-Host "No configuration is provided. Exiting the collection process."
    [Environment]::Exit(1);
}

# -----------------------------------------------------------------------------
$env:PSModulePath += (";" + $pwd + "\Modules")
$env:PSModulePath
Import-Module SecurityScorer -DisableNameChecking  # Helper module for getting security related data and scoring

$globalConfigUri = $config;

# $globalConfigFile="ConfigForSecurityScoring.json";
$globalConfig = Get-GlobalConfig $globalConfigUri

if ($globalConfig -eq $null) {
    Write-Log "No Configuration is loaded. Please check and try again.";    
    [Environment]::Exit(1);
}

$globalConfig.fVerbose = $false;

if (($args.Length -gt 1) -and ($args[0] -eq "-v")) {
    $globalConfig.fVerbose = $true;
}

#Need to make sure WinRM are enabled
$winRMStatus = get-service winrm | select Status
if ($winRMStatus.Status -ne "Running")
{
    winrm quickconfig;
}

# -----------------------------------------------------------------------------
# ToDo: is there an easier way to get Azure credentials logged in?
#   Import-AzurePublishSettingsFile  "fileNamePrefix.publishsettings"
Write-Log "Get Admin credentials for the Tenant Domain."
$AdminCredential = Get-Credential -Message "Give admin credentials to collect Security Score"

Write-Log "Let us ensure that you have the correct powershell modules on your local machine." 3
Check-Presetup ($AdminCredential)

Write-Log "Setup the environment and connect to service management APIs to generate security score"
Load-ModulesForSecurityScorer;
$global:ServiceInfo = @{"EXO" = "True"; "EOP" = "True"; "SPO" = "True"; "AADRM" = "True"; "SFB" = "True"}

$TenantInfo = $null; # initialize the information
try {

    Write-Log " Set up the Service Sessions" 2
    $fSessions = Get-ServiceSessions $AdminCredential
    
    if ($fSessions -eq $true) {
        Write-Log " Get Tenant Information" 2
        $TenantInfo = Get-TenantInfo $AdminCredential
    }

    if ($globalConfig.fVerbose) { 
        $msg = "Connected to Service Sessions: " + $fSessions;
        Write-Log $msg;
        Write-Host "Tenant Info: "
        Write-Output $TenantInfo 
    }
} catch {
    
    Write-Error " Unable to connect to Microsoft Online Services or Azure Active Directory"
    Write-Host $_.Exception;
    $TenantInfo = $null; #  reset on failure
}

if ( $TenantInfo -eq $null) {

    Write-Log " ERROR: NO TENANT Information Is FOUND" 2
    Write-Log "Stop all processing now!"

} else {

    #ToDo: remove the inlining of powershell script once i figure out the bug with in-line expansions.
    Write-Log "Connecting to Office 365 Services" 2

    Write-Log "Connecting to Exchange Online Remote Powershell Service"
    $ExoSession = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $AdminCredential -Authentication Basic -AllowRedirection
    if ($null -ne $ExoSession) { 
        Import-PSSession $ExoSession
    } else {
        Write-Log "  No EXO service set up for this account"
        $ServiceInfo.Set_Item("EXO", "False")
    }

    Write-Log "Connecting to EOP Powershell Service"
    $EopSession = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://ps.compliance.protection.outlook.com/powershell-liveid/ -Credential $AdminCredential -Authentication Basic -AllowRedirection
    if ($null -ne $EopSession) { 
        Import-PSSession $EopSession -AllowClobber
    } else {
        Write-Log "  No EOP service set up for this account"
        $ServiceInfo.Set_Item("EOP", "False")
    }

    Write-Log "Connecting to Azure Active Directory Rights Management Service"
    Try
    {
        $aadrmCmdlets = Connect-AadrmService -Credential $AdminCredential
        if ($null -eq $aadrmCmdlets) {
            Throw "Unable to connect to AADRM Service"
        }
    }
    Catch
    {
        Write-Log "  No AADRM service set up for this account"
        $ServiceInfo.Set_Item("AADRM", "False")        
    }

    # -----------------------------------------------------------------------------
    Write-Log "Loading up the scoring rubric" 2

    # BUG: Powershell unfolds the IEnumerable return type of System.Data.DataTable to produce an array as return value, which we DO not want!
    #    Hence, i pre-create the table and pass it in for the Scoring Table to be filled in
    # ToDo: Convert this System.Data.DataTable to be a dictionary object by "ReferenceID"
    $AllScoresTable = New-Object System.Data.DataTable
    $loadedTable = Get-AttributesForSecurityScoring $globalConfig.ControlsConfigUri $AllScoresTable

    if ($loadedTable.Rows.Count -lt 1) {
        Write-Host "ERROR: Failed to load Controls Configuration. Stop Processing Now" -ForegroundColor Red
        [Environment]::Exit(1);
    }

    Write-Log "Finished setting up the environment and getting the Scoring Attributes"
    if ( $globalConfig.fVerbose -eq $true) {
        Write-Log "Display all Service Info that is to be scanned"
        Write-Output $ServiceInfo
    }

    # -----------------------------------------------------------------------------
    #Lets go get a list of all the users for this tenant so we can do some downstream checks
    Write-Log "Get data about all of your users. This may take a while if you have a lot of users." 2
    $AllUsers = @()
    $UserInboxRules = @()
    $UserDelegates = @()

    $AllUsers = Get-MsolUser -All -EnabledFilter EnabledOnly | select UserPrincipalName, StrongAuthenticationRequirements, StsRefreshTokensValidFrom, AlternateEmailAddresses, StrongPasswordRequired | Where-Object {($_.UserPrincipalName -notlike "*#EXT#*")}

    if ($AllUsers.Count -lt 100)
    {
        Write-Log "Checking for per-mailbox forwarding rules and delegates."

        foreach ($User in $allUsers)
        {
            $msg = "     Check inbox rules and delegates for user: " + $User.UserPrincipalName;
            Write-Log $msg;
            $UserInboxRules += Get-InboxRule -Mailbox $User.UserPrincipalname | Select Name, Description, Enabled, Priority, ForwardTo, ForwardAsAttachmentTo, RedirectTo, DeleteMessage | Where-Object {($_.ForwardTo -ne $null) -or ($_.ForwardAsAttachmentTo -ne $null) -or ($_.RedirectsTo -ne $null)}
            $UserDelegates += Get-MailboxPermission -Identity $User.UserPrincipalName | Where-Object {($_.IsInherited -ne "True") -and ($_.User -notlike "*SELF*")}
        }
    } else {
        $msg = "There are " + $AllUsers.Count + " users. We are skipping per-mail box forwarding rules and delegates for now.";
        Write-Log $msg;
    }

    # -----------------------------------------------------------------------------

    $allScores = Check-AllSecurityControls $TenantInfo $AdminCredential $AllUsers $UserInboxRules $UserDelegates $AllScoresTable 

    # -----------------------------------------------------------------------------
    #  generate output to save in local file as well as for uploads
    $dataToOutput = Get-FinalSecurityScore $TenantInfo $AllScoresTable

    $dataInJson = Save-ScoreDataToFile $TenantInfo $dataToOutput

    Save-ScoreToScorerService $globalConfig.SaveSecureScoreToURI $AdminCredential $dataInJson

    # ToDo: Ensrue UrlEncode can be used. in some environments. The requisite assembly does not load
    # $a = [System.Web.HttpUtility]::UrlEncode($dataToOutput.summary.tenantID)
    # $b = [System.Web.HttpUtility]::UrlEncode($dataToOutput.summary.tenantDomain);
    
    $base = $globalConfig.SecureScoreViewerURL + "?tenantID=" +$dataToOutput.summary.tenantID;
    $base = $base + "&tenantDomain=" +$dataToOutput.summary.tenantDomain;
    Write-Log "Launching the Secure Score Analytics View for your collection." 2;
    $msg = "  Visit " + $base;
    Write-Host $msg;

    start-process $base

    #Cleanup
    Remove-Variable AllScoresTable
} 


Write-Host "";
Stop-Transcript
