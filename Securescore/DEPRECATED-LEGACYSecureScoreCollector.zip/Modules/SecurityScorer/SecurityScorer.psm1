﻿# -----------------------------------------------------------------------------
#  SecurityScorer.psm1
#
#   o Helper functions for calculating the Security Score
#
#   Created: Sep 10, 2015, MuraliK
#
#   ToDo: Migrate bulk of this code to be REST APIs for future reuse from many apps
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
#  GLOBAL VARIABLES
$SFBsession = $null
$ExoSession = $null

$globalResourceLocator = "https://graph.windows.net" # DO NOT CHANGE THIS.
$globalLoginURL      = "https://login.windows.net"   # DO NOT CHANGE THIS.



# -------------------
# Write-Log() - logs a message with pretty spacing by default
#  Inputs:
#     $msg = message to be logged
#     $spaced = should spcaing be provided?
#
Function Write-Log( [String] $msg, [int] $spaced = 1)
{
    if ($spaced -gt 1) {
        Write-Host;
    } 

    if ($spaced -eq 2) {
        Write-Host " -+-+-+-+-+ -+-+-+-+-+ -+-+-+-+-+ -+-+-+-+-+ -+-+-+-+-+ -+-+-+-+-+ -+-+-+-+-+ -+-+-+-+-+";
    } elseif ($spaced -eq 3) {
        Write-Host "---------------------------------------------------------------------------------------";
    }

    Write-Host $msg;
}

Export-ModuleMember -Function Write-Log

# -------------------
# Write-Error() - writes an error message
#  Inputs:
#     $msg = message to be logged
#     $spaced = should spcaing be provided?
#
Function Write-Error( [String] $msg, [int] $spaced = 1)
{
    $bannerHeader = " -+-+-+-+-+ -+-+-+-+-+ -+-+-+-+-+ -+-+-+-+-+ -+-+-+-+-+ -+-+-+-+-+ -+-+-+-+-+ -+-+-+-+-+";
    if ($spaced -eq 1) {
        $locHeader = "";
    } elseif ($spaced -eq 2) {
        $locHeader = $bannerHeader;
    }

    Write-Host $locHeader;
    $msg = " ERROR: " + $msg;
    Write-Host $msg -ForegroundColor Red;

    if ($spaced -ne 0) {
        Write-Host;
    } 
}

Export-ModuleMember -Function Write-Error


#ToDo: Write doc for Load-ModulesForSecurityScorer
Function Load-ModulesForSecurityScorer()
{

    Write-Log "Loading Azure related modules" 2
    Import-Module MSOnline     # Load Azure related modules

    # Load Azure Commandlets using NEW PATH in v0.9.7
    # ToDo: Avoid the need to explicitly hard code the paths for Azure commandlets
    #Load up the Azure Service Management Modules
	$azurePSRoot="C:\Program Files (x86)\Microsoft SDKs\Azure\Powershell"
    $azureServiceManagementModule= $azurePSRoot + "\ServiceManagement\Azure\Azure.psd1"
    Write-Log("Loading Azure module: "+$azureServiceManagementModule)
    Import-Module $azureServiceManagementModule

	#Load up the Azure AD Rights Management Module
	Write-Log("Loading AAD Rights Management module.")
    Import-Module aadrm

    #Load up the SharePoint Online Module
    Write-Log("Loading SharePoint Online module.")
    Import-Module Microsoft.Online.SharePoint.PowerShell -DisableNameChecking

	# Skype for Business Module - was checked for in the PreSetup - forego it here
}
Export-ModuleMember -Function Load-ModulesForSecurityScorer

Function Get-GlobalConfigFromFile( $configFile)
{
    $msg = "Loading Global Config File from " + $configFile;
    Write-Log $msg 2
    
    $config = Get-Content $globalConfigFile -Raw | ConvertFrom-Json

    # Make the path for security config a full path
    if (!(Split-Path -Path $config.SecurityScoreConfig -IsAbsolute)) {

        $currentDir=pwd
        $config.SecurityScoreConfig = $currentDir.Path + "\" + $config.SecurityScoreConfig
    }

    # Error out if there is no global config or if there is a failure to load the config file
    if (!(Test-Path $config.SecurityScoreConfig)) {
        $msg = "ERROR: Global Configuration file " + $config.SecurityScoreConfig + " is missing";
        Write-Host $msg;
        $config = null;
    }
    
    return $config;
}


Function Get-GlobalConfig( $configUri)
{
    $msg = "Loading Global Config from: " + $configUri;
    Write-Log $msg 2

    Try {
        $download = Invoke-WebRequest $configUri 
        $config = ($download.Content |  ConvertFrom-Json);

    } Catch {
 
        $ErrorMessage = $_.Exception.Message
        Write-Host "Failed to download configuration file for Security Score."
        Write-Host " ERROR: $ErrorMessage";
        $config = $null;
    }
    
    return $config;
}

Export-ModuleMember -Function Get-GlobalConfig


#ToDo: Write doc for Get-ServiceSessions
#ToDo: Handle errors per service we attempted to connect with
#ToDo: DO per-service connection and evaluation 
# Returns: TenantInfo object that is used for many other functions
Function Get-ServiceSessions( $userCredential)
{
    $fServiceSession = $true;

    #ToDo: check on $error to make sure there are no errors; or at least handle it
    #ToDo: use Try/Catch/Finally block to handle exception and errors

    Write-Log "Connecting to Azure"
    Add-AzureAccount -Credential $userCredential

    Try {
        Write-Log "Connecting to Azure Active Directory"
        Connect-MsolService -Credential $userCredential
    } Catch {
        $ErrorMessage = $_.Exception.Message
        Write-Host "Failed to connect to Microsoft Online Service."
        Write-Host " ERROR: $ErrorMessage";
        $fServiceSession = $false;
    }

    return $fServiceSession;
}
Export-ModuleMember -Function Get-ServiceSessions

function Load-ActiveDirectoryAuthenticationLibrary()
{
  $moduleDirPath = [Environment]::GetFolderPath("MyDocuments") + "\WindowsPowerShell\Modules"
  $modulePath = $moduleDirPath + "\AADGraph"
  if(-not (Test-Path ($modulePath+"\Nugets"))) {New-Item -Path ($modulePath+"\Nugets") -ItemType "Directory" | out-null}

  $adalPackageDirectories = (Get-ChildItem -Path ($modulePath+"\Nugets") -Filter "Microsoft.IdentityModel.Clients.ActiveDirectory*" -Directory)
  if($adalPackageDirectories.Length -eq 0){
    Write-Host "Active Directory Authentication Library Nuget doesn't exist. Downloading now ..." -ForegroundColor Yellow
    if(-not(Test-Path ($modulePath + "\Nugets\nuget.exe")))
    {
      Write-Host "nuget.exe not found. Downloading from http://www.nuget.org/nuget.exe ..." -ForegroundColor Yellow
      $wc = New-Object System.Net.WebClient
      $wc.DownloadFile("http://www.nuget.org/nuget.exe",$modulePath + "\Nugets\nuget.exe");
    }
    $nugetDownloadExpression = $modulePath + "\Nugets\nuget.exe install Microsoft.IdentityModel.Clients.ActiveDirectory -Version 2.14.201151115 -OutputDirectory " + $modulePath + "\Nugets | out-null"
    Invoke-Expression $nugetDownloadExpression
  }

  $adalPackageDirectories = (Get-ChildItem -Path ($modulePath+"\Nugets") -Filter "Microsoft.IdentityModel.Clients.ActiveDirectory*" -Directory)
  $ADAL_Assembly = (Get-ChildItem "Microsoft.IdentityModel.Clients.ActiveDirectory.dll" -Path $adalPackageDirectories[$adalPackageDirectories.length-1].FullName -Recurse)
  $ADAL_WindowsForms_Assembly = (Get-ChildItem "Microsoft.IdentityModel.Clients.ActiveDirectory.WindowsForms.dll" -Path $adalPackageDirectories[$adalPackageDirectories.length-1].FullName -Recurse)
  
  if($ADAL_Assembly.Length -gt 0 -and $ADAL_WindowsForms_Assembly.Length -gt 0){
    Write-Host "Loading ADAL Assemblies ..."
    Write-Host "  Please login to the pop-up Window with the same admin account credentials" -ForegroundColor Green
    [System.Reflection.Assembly]::LoadFrom($ADAL_Assembly[0].FullName) | out-null
    [System.Reflection.Assembly]::LoadFrom($ADAL_WindowsForms_Assembly.FullName) | out-null
    return $true
  }
  else{
    Write-Host "Fixing Active Directory Authentication Library package directories ..." -ForegroundColor Yellow
    $adalPackageDirectories | Remove-Item -Recurse -Force | Out-Null
    Write-Host "Not able to load ADAL assembly. Delete the Nugets folder under" $modulePath ", restart PowerShell session and try again ..."
    return $false
  }
}
Export-ModuleMember -Function Load-ActiveDirectoryAuthenticationLibrary

function Get-TokenResult( $config)
{
  Write-Host "Getting Access Token for resource: " $config.resourceAppIdUri;

  $authContext = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext" -ArgumentList $config.authority,$false
  $authResult = $authContext.AcquireToken( $config.resourceAppIdURI, $config.clientID, $config.redirectUri, [Microsoft.IdentityModel.Clients.ActiveDirectory.PromptBehavior]::Always)
  
  Write-Host " ... obtained Access Token of type: " $authResult.AccessTokenType;
  return $authResult
}
Export-ModuleMember -Function Get-TokenResult

function Get-AuthenticationResult($tenant = "common", $env="prod")
{
  $authority = "https://login.windows.net/" + $tenant
  $resourceAppIdURI = "https://graph.windows.net"
  if($env.ToLower() -eq "ppe"){$resourceAppIdURI = "https://graph.ppe.windows.net/"; $authority = "https://login.windows-ppe.net/" + $tenant}
  elseif($env.ToLower() -eq "china"){$resourceAppIdURI = "https://graph.chinacloudapi.cn/"; $authority = "https://login.chinacloudapi.cn/" + $tenant}

  $authConfig = @{
    authority = $authority;
    resourceAppIdURI = $resourceAppIdURI;
    clientID = "1950a258-227b-4e31-a9cf-717495945fc2"; # Client ID for the AAD connection
    redirectUri = "urn:ietf:wg:oauth:2.0:oob";
  };

  return Get-TokenResult $authConfig
}

Export-ModuleMember -Function Get-AuthenticationResult


function Connect-AAD ($tenant = "common", $env="prod", $graphVer="beta") {
  PROCESS {
    $global:aadGPoShAuthResult = $null
    $global:aadGPoShEnv = $env
    $global:aadGPoShGraphVer = $graphVer
    $global:aadGPoShGraphUrl = "https://graph.windows.net/"

    if($env.ToLower() -eq "ppe") {$global:aadGPoShGraphUrl = "https://graph.ppe.windows.net/"}
    elseif($env.ToLower() -eq "china") {$global:aadGPoShGraphUrl = "https://graph.chinacloudapi.cn/"}
    $global:aadGPoShAuthResult = Get-AuthenticationResult -Tenant $tenant -Env $env
  }
}
Export-ModuleMember -Function Connect-AAD


Function Get-TenantInfo( $userCredential)
{

    Write-Log "Creating the Tenant Info object for local use"

    $tenantInfo=@{}
    $tenantInfo.AdminName = $userCredential.UserName

    $tenantInfo.MyDomain = (Get-MsolDomain | Where-Object -Property IsDefault -EQ "True")
    if ( $tenantInfo.MyDomain -ne $null) {
        $tenantInfo.inputDomainName = $tenantInfo.MyDomain.Name
    }

    $tenantInfo.CompanyInfo = Get-MsolCompanyInformation 
    $subscriptions = Get-AzureSubscription;
    if ($subscriptions -ne $null) {
        $tid = ($subscriptions | where-object {($_.DefaultAccount -eq $userCredential.UserName)} | Select -ExpandProperty TenantID);
        if ($tid -is [System.Array]) { $tenantInfo.TenantGUID = $tid[0]; }
        else { $tenantInfo.TenantGUID = $tid;}
    }

    if (($subscriptions -eq $null) -or
        ($tenantInfo.TenantGUID -eq $null))
    {
        Write-Log "WARNING : NO Azure Subscription is owned by this logged in account." 2
        Write-Log "       We are fetching Subscription and TenantGUID from accounts"

        $accounts = Get-AzureAccount;

        foreach ($account in $accounts) {
            $msg = "Iteratating through account: " + $account.Id
            Write-Log $msg 2

            if ($account.Id -eq $tenantInfo.AdminName ) {
            
                $tenantInfo.TenantGUID = $account.Tenants.substring(0, 36);
                $msg = "Updated TenantGUID is: "+$tenantInfo.TenantGUID;
                Write-Host $msg;
                break;
           }
        }
    }

    $tenantInfo.TenantName = $tenantInfo.CompanyInfo | Select -ExpandProperty DisplayName
    $tenantInfo.GroupInfo = Get-MsolRole

    #Moving the population of this to the main program
    $tenantInfo.PWAgePolicy= Get-MsolPasswordPolicy -DomainName $tenantInfo.inputDomainName

    #This will support MFA checks downatream
    $federatedRootDomains = @()
    $federatedRootDomains = Get-MsolDomain -Status Verified | Where-Object {($_.Authentication -eq "Federated") -and ($_.RootDomain -eq $null)} | select *
    foreach ($federatedDomain in $federatedRootDomains) 
    {
        if (Get-MsolDomainFederationSettings -DomainName $federatedDomain.Name | Where-Object {($_.SupportsMfa -eq $true)})
        {
            $tenantInfo.FederatedDomainSupportsMFA += $federatedDomain.Name
        }
    }
    
    if ($globalConfig.fVerbose) {
        Write-Host "We found following subscriptions for your admin account: ";
        $subscriptions;

        $msg = "and the tenant GUID for your default admin account is: " + $tenantInfo.TenantGUID;
        Write-Host $msg;
    }

    if ( ($tenantInfo.TenantGUID -eq $null) -or 
         ($tenantInfo.inputDomainName -eq $null)
         ) {

         Write-Error "Unable to get the Tenant GUID or InputDomain Name.";
         $tenantInfo = $null;
    }
    
    return $tenantInfo;
}

Export-ModuleMember -Function Get-TenantInfo

Function Get-AttributesForSecurityScoring( $controlsUri, $scoresTable)
{
    #Create a Table Structure to store the results of each test
    if ($scoresTable -eq $null) {
        $secureScoreTable = New-Object System.Data.DataTable
    } else {
        $secureScoreTable = $scoresTable;
    }

    # define the columns required
    $secureScoreTable.Columns.Add("ReferenceID")
    $secureScoreTable.Columns.Add("Type")
    $secureScoreTable.Columns.Add("Class")
    $secureScoreTable.Columns.Add("Control")
    $secureScoreTable.Columns.Add("Action")
    $secureScoreTable.Columns.Add("ActionURL")
    $secureScoreTable.Columns.Add("Workload")
    $secureScoreTable.Columns.Add("Baseline", [int])
    $secureScoreTable.Columns.Add("Score", [int])
    $secureScoreTable.Columns.Add("Enablement")

    $msg = "   Load Security Score Controls from: " + $controlsUri;
    Write-Log $msg;

    Try {

        $download = Invoke-WebRequest $controlsUri 
        $scoreConfigInputs = ($download.Content |  ConvertFrom-Json);
    } Catch {
     
        $ErrorMessage = $_.Exception.Message
        Write-Host "Failed to    for Security Score."
        Write-Host " ERROR: $ErrorMessage";
        $scoreConfigInputs = $null;
    }

    if ($scoreConfigInputs -ne $null) {

        $intRow = 0; # start at the third row - first 1 row is a header
        do {
            # $msg = "     Read control[" + $intRow + "] : Class=" + $scoreConfigInputs[$intRow].Class + "; ID=" + $scoreConfigInputs[$intRow].ReferenceID
            # Write-Log $msg;

            #Add a Sample Row to this table
            $row = $secureScoreTable.NewRow()

            $row["Type"] = $scoreConfigInputs[$intRow].Type;
            $row["Class"] =  $scoreConfigInputs[$intRow].Class;
            $row["ReferenceID"] = $scoreConfigInputs[$intRow].ReferenceID;
            $row["Control"] = $scoreConfigInputs[$intRow].Control;
            $row["Action"] = $scoreConfigInputs[$intRow].Action;
            $row["Baseline"] = $scoreConfigInputs[$intRow].Baseline;
            $row["Enablement"] = $scoreConfigInputs[$intRow].Enablement;
            $row["Workload"] = $scoreConfigInputs[$intRow].Workload;
            $row["ActionURL"] = $scoreConfigInputs[$intRow].ActionURL;
            $row["Score"] = "0";

            $secureScoreTable.Rows.Add($row)
            $intRow++

        } While ($intRow -lt $scoreConfigInputs.Length);

    }

    $msg = "In total, we read in " + $secureScoreTable.Rows.Count + " attributes for scoring"
    Write-Log $msg

    # add , at the start to prevent Powershell from unrolling my return type to be an array
    return @(,[System.Data.DataTable] $secureScoreTable);
}

Export-ModuleMember -Function Get-AttributesForSecurityScoring


Function Write-SummaryOfScores( $secureScoreTable, $fDetails = $false) 
{
    Write-Log -msg "Quick Summary of Scores:" -spaced 2
    foreach ($row in $secureScoreTable) {

        Write-Host " " $row.Score -NoNewline
    }

    Write-Host
}

Export-ModuleMember -Function Write-SummaryOfScores

Function Set-Score( $scoringTable, $scoreName, $score) {

   $row = ($scoringTable.Rows | Where-Object {($_.ReferenceID -eq $scoreName)});
   if ($row -ne $null) { $row.Score = $score;}
}

Export-ModuleMember -Function Set-Score

Function Set-ScoreForAttributeMax( $scoringTable, $attributeReference, $attribute, $max)
{
    if ($attribute -lt $max) { $score = "10"; }
    else { $score="0"; } 

    ($scoringTable.Rows | Where-Object {($_.ReferenceID -eq $attributeReference)}).Score = $score;
    return $score;
}
Export-ModuleMember -Function Set-ScoreForAttributeMax

Function Set-ScoreForAttributeState( $scoringTable, $attributeReference, $attribute)
{
    if ($attribute -eq "TRUE") { $score = "10"; }
    else { $score="0"; } 
    
    ($scoringTable.Rows | Where-Object {($_.ReferenceID -eq $attributeReference)}).Score = $score;
    return $score;
}
Export-ModuleMember -Function Set-ScoreForAttributeState

#This marks the beginning of the mega-functions to check and return the score for each check type##########################################
###########################################################################################################################################

Function Check-TenantWidePolicies( $tenantInfo, $AllUsers, $secureScoreTable)
{

    Write-Log "Checking on your current tenant-wide password policy."

    #ToDo: What is the Domain name had more than one entry
    #ToDo1: For now we only fetch the first item. ex: $MyDomain.Name[0]

    #Get Current Password Policy set on the domain (no results means 90 day expiration and 14 days notification)
    Write-Log " Checking for Password Age Policy"
    $TenantChecks=@{}
    $TenantChecks.PWAgePolicyScore = Set-ScoreForAttributeMax $secureScoreTable "PWAgePolicy" $tenantInfo.PWAgePolicy.ValidityPeriod 60

    Write-Log "  Checking if Self-service Password Reset is enabled for this tenant"
    $TenantChecks.SSPWReset= $tenantInfo.CompanyInfo | Select SelfServePasswordResetEnabled
    $TenantChecks.SSPWResetScore = Set-ScoreForAttributeState $secureScoreTable "SSPWReset" $TenantChecks.SSPWReset.SelfServePasswordResetEnabled

    Write-Log "  Checking if your tenant admins have MFA enabled."

    #Tenant Admins do not have MFA Enabled
    #Need to update this to consume new $tenantInfo.FederatedDomainSupportsMFA variable on a per-user check
    $score = 0;
    if ( $tenantInfo.GroupInfo -ne $null) 
    {
        $admingroupguid = $tenantInfo.GroupInfo | where { $_.Name.Contains("Company Administrator")} | Select ObjectId
        $TenantChecks.TenantAdmins = @(Get-MsolRoleMember -RoleObjectId $admingroupguid.ObjectId | select EmailAddress)
        $thisAdminMFACount=0;
        foreach ($AdminUser in $TenantChecks.TenantAdmins) 
            { 
                $thisAdminSettings = Get-MsolUser -UserPrincipalName $AdminUser.EmailAddress | Select DisplayName, StrongAuthenticationRequirements;
                if (($thisAdminSettings.StrongAuthenticationRequirements) -or ($AdminUser.EmailAddress.Split("@")[1] -in $tenantInfo.FederatedDomainSupportsMFA))
                    {
                        $thisAdminMFACount++;
                    }
            }
        if ($TenantChecks.TenantAdmins.Count -gt 0) 
        {
            $score = ($thisAdminMFACount  / $TenantChecks.TenantAdmins.Count);
        } 
    }
    $TenantChecks.AdminMFAScore = [math]::Round(($secureScoreTable.Rows | Where-Object {($_.ReferenceID -eq "AdminMFA")}).Baseline * $score);

    ($secureScoreTable.Rows | Where-Object {($_.ReferenceID -eq "AdminMFA")}).Score = $TenantChecks.AdminMFAScore

    Write-Log "  Checking on security configurations for your users."

    #Users who do not have MFA Enabled, Strong Password Complexity Policy not Required
    $thisUsersMFACount = 0;
    foreach ($User in $AllUsers) 
    { 
        $msg = "    Checking Password Policies for user: " + $User.UserPrincipalName;
        Write-Log $msg;
        #Check for MFA
        if (($User.StrongAuthenticationRequirements) -or ($User.UserPrincipalName.Split("@")[1] -in $tenantInfo.FederatedDomainSupportsMFA))
            {
                $thisUsersMFACount++;
            }

        #Check for Strong Password
        if (!$User.StrongPasswordRequired)
            {
                $thisUsersStrongPWCount++;
            }
    }

    $score = 0;
    if ($AllUsers.Count -gt 0) {
        $score = ($thisUsersMFACount / $AllUsers.Count);
    } 
    $UserMFAScore = [math]::Round(($secureScoreTable.Rows | Where-Object {($_.ReferenceID -eq "UserMFA")}).Baseline * $score)
    ($secureScoreTable.Rows | Where-Object {($_.ReferenceID -eq "UserMFA")}).Score = "$UserMFAScore";

    $TenantChecks.UserMFAScore = $UserMFAScore;

    $score = 0;
    if ($AllUsers.Count -gt 0) {
        $score = ($thisUsersStrongPWCount / $AllUsers.Count);
    } 
    #ToDo: $UserStrongPWScore needs to be calculated outside this loop. No?
    $UserStrongPWScore = [math]::Round(($secureScoreTable.Rows | Where-Object {($_.ReferenceID -eq "StrongPW")}).Baseline * $score)
    ($secureScoreTable.Rows | Where-Object {($_.ReferenceID -eq "StrongPW")}).Score = "$UserStrongPWScore";
    $TenantChecks.UserStrongPWScore = $UserStrongPWScore;

    return $TenantChecks;
}

Export-ModuleMember -Function Check-TenantWidePolicies


Function Check-DevicePolicies( $tenantInfo, $secureScoreTable)
{
    if ($ServiceInfo.EOP -eq "False") 
    { 
        write-host "Can't do IP MDM checks because it is not enabled.";     
    }
    else
    {
        Write-Log "Checking mobile device management configurations." 2
        $deviceConfigurationRule = Get-DeviceConfigurationRule

        if ( $deviceConfigurationRule -eq $null) {

            Write-Log "  No mobile device management policies found."
            return $null;
        }

        $DeviceChecks = @{};

        #New School Mobile Device Management Checks
        $MDMPolicy = $deviceConfigurationRule | select Name, PasswordRequired, AllowSimplePassword, PasswordMinComplexChars, PasswordMinimumLength, MaxPasswordAttemptsBeforeWipe, PasswordTimeout, PasswordExpirationDays, PasswordHistoryCount, PhoneMemoryEncrypted, AllowJailbroken, RequireEmailProfile, Mode

        #Check if MDM is enabled/required - AllowNonProvisionableDevices
        if ($MDMPolicy.Mode -eq "Enforced") {   $DeviceChecks.MDMEnabled = "50"; } else { $DeviceChecks.MDMEnabled = "0"}

        #Check if MDM Requires Passwords - PasswordEnabled
        if ($MDMPolicy.PasswordRequired -eq "True") {   $DeviceChecks.MDMPWReq = "10"; } else { $DeviceChecks.MDMPWReq = "0"}

        #Check if MDM Prevents Simple passwords - AllowSimplePassword
        if ($MDMPolicy.AllowSimplePassword -ne "True") { $DeviceChecks.MDMSimplePW ="5"; } else { $DeviceChecks.MDMSimplePW = "0"}

        #Check if MDM Requires AlphaNumeric Passwords - AlphanumericPasswordRequired
        if ($MDMPolicy.PasswordMinComplexChars -gt "2") { $DeviceChecks.MDMAlphaPW = "5"; }  else { $DeviceChecks.MDMAlphaPW = "0"}

        #Cheeck if MDM Requires minimum password length - MinPasswordLength
        if ($MDMPolicy.PasswordMinimumLength -gt "5") { $DeviceChecks.MDMMinPW = "5"; }  else { $DeviceChecks.MDMMinPW = "0"}

        #Check if MDM Requires wipe on sign-in failures - MaxPasswordFailedAttempts
        if ($MDMPolicy.MaxPasswordAttemptsBeforeWipe -lt "10") { $DeviceChecks.MDMWipeOnFail = "5"; }  else { $DeviceChecks.MDMWipeOnFail = "0"}

        #Check if MDM locks on inactivity - MaxInactivityTimeLock
        if ($MDMPolicy.PasswordTimeout -ne $null) { $DeviceChecks.MDMLockInactive = "5"; }  else { $DeviceChecks.MDMLockInactive = "0"}

        #Check if MDM expires the password - PasswordExpiration
        if ($MDMPolicy.PasswordExpirationDays -lt "180") { $DeviceChecks.MDMPWExpire = "1"; }  else { $DeviceChecks.MDMPWExpire = "0"}

        #Check if MDM prevents password re-use - PasswordHistory
        if ($MDMPolicy.PasswordHistoryCount -lt "6") { $DeviceChecks.MDMPWReuse = "1"; }  else { $DeviceChecks.MDMPWReuse = "0"}

        #Check if MDM requires encryption - RequireDeviceEncryption
        if ($MDMPolicy.PhoneMemoryEncrypted -eq "True") { $DeviceChecks.MDMEncryptReq = "5"; }  else { $DeviceChecks.MDMEncryptReq = "0"}

        #Check if MDM blocks rooted devices - AllowUnsignedApplications
        if ($MDMPolicy.AllowJailbroken -eq "True") { $DeviceChecks.MDMRootedBlock = "5"; }  else { $DeviceChecks.MDMRootedBlock = "0"}

        #Check if MDM Requires managing email profile - AllowConsumerEmail
        if ($MDMPolicy.RequireEmailProfile -eq "True") { $DeviceChecks.MDMManageEmail = "10"; }  else { $DeviceChecks.MDMManageEmail = "0"}

	    #Check if the MDM Policy is blocked and report, or allowed and report: DeviceConditionalAccess == Block, DeviceSettings == Allow
        if ($tenantInfo.DevicePolicy.Type -eq "DeviceConditionalAccess") { $DeviceChecks.MDMReportViolation = "10"; } else { $DeviceChecks.MDMReportViolation = "0" } 
    
	    # Update the scores in the main score table
        foreach ($key in $DeviceChecks.Keys) {

            Set-Score $secureScoreTable $key $DeviceChecks[$key]
        }

        return $DeviceChecks;
    }
}

Export-ModuleMember -Function Check-DevicePolicies


Function Check-SharingPolicies( $tenantInfo, $secureScoreTable)
{
    Write-Log "Checking Sharing Configuration for the tenant." 2

    $SharingChecks = @{};

    #What is the global sharing policy? Four possible cases: anonymous:0, Anonymous:CalendarSharingFreeBusySimple, Anonymous:CalendarSharingFreeBusyDetail, Anonymous:CalendarSharingFreeBusyReviewer
    $CalSharingPolicy = Get-SharingPolicy | Select Domains

    if ( $CalSharingPolicy -eq $null) {

        Write-Error "  Unable to find Calendar Sharing Policies."
    } else {

        #Check for PublicURLCalendar - Anonymous:CalendarSharingFreeBusyReviewer
        if ($CalSharingPolicy.Domains -notcontains "Anonymous:CalendarSharingFreeBusyReviewer") { $SharingChecks.PublicURLCalendar = "10"; } else {  $SharingChecks.PublicURLCalendar = "0"; }

        #Check for Anonymous Calendar - anonymous:0
        if ($CalSharingPolicy.Domains -notcontains "anonymous:0") { $SharingChecks.AnonymousCalendar = "10"; } else {  $SharingChecks.AnonymousCalendar = "0"; }

        #Check for Calendar Details - Anonymous:CalendarSharingFreeBusyDetail
        if ($CalSharingPolicy.Domains -notcontains "Anonymous:CalendarSharingFreeBusyDetail")  { $SharingChecks.CalendarDetails = "5"; } else {  $SharingChecks.CalendarDetails = "0"; }
    }

    #External App Sharing Enabled?
    $IntegratedAppSharingPolicy = Get-MsolCompanyInformation | Select UsersPermissionToUserConsentToAppEnabled 
    if ( $IntegratedAppSharingPolicy -eq $null) {

        Write-Error "  Unable to find Integrated App Sharing Policy."
    } else {
        if ($IntegratedAppSharingPolicy.usersPermissionToUserConsentToAppEnabled -ne "True") { $SharingChecks.IntegratedApps = "10"; } else {  $SharingChecks.IntegratedApps = "0"; }
    }

    # Update the scores in the main score table
    foreach ($key in $SharingChecks.Keys) {

        Set-Score $secureScoreTable $key $SharingChecks[$key]
    }


    return $SharingChecks;
}

Export-ModuleMember -Function Check-SharingPolicies

Function Check-AdvancedPolicies( $tenantInfo, $secureScoreTable)
{
    Write-Log "Checking Advanced Policies for the tenant." 2

    $AdvancedChecks = @{};


    #ToDo: E5 Config check does not work if there is no Advanced Threat Protection
    #FUTURE ADDITION: Do they have E5, and therefore Advanced Threat Protection?
    #$ATPSku = Get-MsolAccountSku | Select AccountSkuId
    #if ($ATPSku.AccountSkuID -notcontains "ENTERPRISEPACK") { ($SecureScoreTable.Rows | Where-Object {($_.ReferenceID -eq "ATPEnabled")}).Score = "30"; }
    if ($ServiceInfo.EOP -eq "False")
    {
        Write-Host "  Cannot do IP checks because it is not enabled for this tenancy."
    }
    else
    {
        #Do we have an aggressive anti-malware policy?
        $MalwarePolicy = get-malwarefilterpolicy | Where-Object {($_.isDefault -eq "True")}
        if ($MalwarePolicy.Action -eq "DeleteMessage")  { $AdvancedChecks.WeakMalware = "15"; } else {  $AdvancedChecks.WeakMalware = "0"; }

        #Do we filter outbound spam?
        $SpamPolicy = Get-HostedOutboundSpamFilterPolicy
        if ($SpamPolicy.NotifyOutboundSpam -eq "True")  { $AdvancedChecks.WeakSpam = "15"; } else {  $AdvancedChecks.WeakSpam = "0"; }

        #If this returns anything, good on them! Give 'em some points.
        $DLPPolicy = Get-DlpPolicy
        if ($DLPPolicy.State -eq "Enabled")  { $AdvancedChecks.DLPEnabled = "5"; } else {  $AdvancedChecks.DLPEnabled = "0"; }
    }

    if ($ServiceInfo.AADRM -eq "False")
    {
        Write-Host "  Cannot do AAD Rights Management Checks because it is not enabled."
    }
    else
    {	
	    #If this returns anything, good on them! Give 'em some more points!
        $IRMEnabled = Get-Aadrm
        if ($IRMEnabled -eq "Enabled")  { $AdvancedChecks.IRMEnabled = "15"; } else {  $AdvancedChecks.IRMEnabled = "0"; }
    }
    # Update the scores in the main score table
    foreach ($key in $AdvancedChecks.Keys) {

        Set-Score $secureScoreTable $key $AdvancedChecks[$key]
    }

    return $AdvancedChecks;
}

Export-ModuleMember -Function Check-AdvancedPolicies


Function Check-BehaviorPolicies( $tenantInfo, $AllUsers, $UserInboxRules, $UserDelegates, $secureScoreTable)
{
    Write-Log "Checking Behavior level policies for the tenant." 2

    $BehaviorChecks = @{};

    
    Write-Log " 1. First check on the Admin Behavior"

    #How Many Administrators does the tenancy have? Only one Tenant Admin Designated, More than 5 Tenant Admins

    if ( $tenantInfo.GroupInfo -ne $null) {

        $admingroupguid = $tenantInfo.GroupInfo | where { $_.Name.Contains("Company Administrator")} | Select ObjectId
        $AdminCount = Get-MsolRoleMember -RoleObjectId $admingroupguid.ObjectId | measure | Select Count

        $msg = " It looks like you have " + $AdminCount.Count + " adminsitrators in your tenancy"
        Write-Log $msg;
    } else {

        Write-Error " Administrators group is NOT found!"
        $AdminCount = 0;
    }

    $BehaviorChecks.ManyAdmin = @{$true="0"; $false="1"}[ $AdminCount.Count -gt 5];

    $BehaviorChecks.OneAdmin= @{$true="0"; $false="2"}[ $AdminCount.Count -lt 2];


    Write-Log " 2. Check on multiple roles, old passwords, incomplete info, inactive accounts, mailbox delegation and mail forwarding rules."

    $thisUsersRolesCount = 0;
    $thisUsersPWAgeCount = 0;
    $thisUsersAltEmailCount = 0;
    $thisUsersLastLogonCount = 0;
    $thisUsersDelegateCount = 0;
    $thisUsersMBForwardingRulesCount=0;
    $thisUsersStrongPWCount=0;

    $nonGlobalAdminUsers = @()
    $nonGlobalAdminRole = Get-MsolRole | Where-Object {($_.Name -ne "Company Administrator")}

    foreach ($role in $nonGlobalAdminRole)
    {
        Write-Output "-----------------"
        Write-Output "Getting the Users for this role: " $role.Name
        $nonGlobalAdminUsers += Get-MsolRoleMember -All -RoleObjectId $role.ObjectId | Where-Object {($_.RoleMemberType -eq "User")} | Select EmailAddress
        Write-Output " "
    }

    if ($nonGlobalAdminUsers.Count -gt 0) 
    { 
        Write-Output "You are leveraging limited admin roles. Nice work."; 
        $thisUsersRolesCount++; 
    }

    #Multiple Roles, Old Passwords, incomplete info
    foreach ($User in $AllUsers) 
    { 

        $msg = "    Checking on the per-user details for " + $User.UserPrincipalName
        Write-Log $msg

        #Check for Last Password Reset being greater than the policy
        if ($User.StsRefreshTokensValidFrom)
        {
            $now = Get-Date
            $pwage = New-TimeSpan -Start $User.StsRefreshTokensValidFrom -End $now
            if ($pwage.Days -gt $tenantInfo.PWAgePolicy.ValidityPeriod) 
            {
                $thisUsersPWAgeCount++;
            }
        }
        #Check for alternate email
        if (!$User.AlternateEmailAddress)
            {
                $thisUsersAltEmailCount++;
            }
        
        #Disabling this until we can get a coherent data source for logons
        #Check for last logons
        # $monthAgo = (Get-Date).AddDays(-30).ToString('MM-dd-yyyy')
        # $today = (Get-Date).ToString('MM-dd-yyyy')
        #$thisUsersLastLogon = Search-UnifiedAuditLog -StartDate $monthAgo -EndDate $today -RecordType AzureActiveDirectoryAccountLogon -UserIds $User.UserPrincipalName
        $thisUsersLastLogon = "Y"
        if ($thisUsersLastLogon)
            {
                $thisUsersLastLogonCount++;
            }

        #Check for Strong Password
        if (!$User.StrongPasswordRequired)
            {
                $thisUsersStrongPWCount++;
            }
    }

    #NEED TO REFACTOR THIS TO GO THROUGH USERS UNTIL WE FIND EVEN ONE DELEGATE OR EVEN ONE GLOBAL MAIL FORWARDING RULE, THEN GIVE THEM A ZERO AND MOVE ON
    #Check for mailbox delegation
    if ($UserDelegates.Count -gt 1)
    {
        $thisUsersDelegateCount++;
    }

    #Check for Mail forwarding and redirection rules
    if ($UserInboxRules.Count -gt 0)
    {
        $thisUsersMBForwardingRulesCount++;
    }

    #ToDo: Check on sub-folder permission details in EXO
    #Future Check to ding them if they are granting permissions to sub-folders
    #Get-MailboxFolderPermission -Identity "admin@a830edad9050849NDA3313.onmicrosoft.com" | Format-List


    #Score them if they've got a people in more than one admin role
    $BehaviorChecks.RoleOverlap = @{$true="1"; $false="0"}[ $thisUsersRolesCount -gt 0];

    #Score them if they've got people with poor password quality
    $BehaviorChecks.PWComplexity = @{$true="0"; $false="1"}[ $thisUsersStrongPWCount -gt 0];

    #Score them if they've got people with incomplete alternate emails
    $BehaviorChecks.AltInfoIncomplete = @{$true="0"; $false="1"}[ $thisUsersAltEmailCount -gt 0];
    
    #Score them if they've got people who haven't logged in in the last 30 days
    $BehaviorChecks.InactiveAccounts = @{$true="0"; $false="1"}[ $thisUsersLastLogonCount -gt 0];

    #Score them if they have a bunch of delegates on their mailboxes
    $BehaviorChecks.MBDelegation = @{$true="0"; $false="1"}[ $thisUsersDelegateCount -gt 0];

    #Score them if their password age is within policy
    $BehaviorChecks.PWAge= @{$true="0"; $false="1"}[ $thisUsersPWAgeCount -gt 0];

    $BehaviorChecks.MailForwardingAll = @{$true="0"; $false="1"}[ $thisUsersMBForwardingRulesCount -gt 0];

    # ToDo: $thisUsersMBForwardingRulesCoun

 
    # Update the scores in the main score table
    foreach ($key in $BehaviorChecks.Keys) {

        Set-Score $secureScoreTable $key $BehaviorChecks[$key]
    }

    return $BehaviorChecks;
}

Export-ModuleMember -Function Check-BehaviorPolicies


Function Check-TenantAlerts( $tenantInfo, $secureScoreTable)
{

    if ($ServiceInfo.EOP -eq "False")
    {
        Write-Host "IP not enabled for this tenancy so can't run checks."
    }
    else
    {
        Write-Log "Checking Alerts for this tenant." 2

        $AlertChecks = @{};
    
        Write-Log " 1. Are there any DLP Alerts"
        $DLPAlerts = Get-MailDetailDlpPolicyReport
        # ToDo: Check the details behind the DLP Alerts and how to add to scores.
        $AlertChecks.DLPViolations= @{$true="10"; $false="0"}[!$DLPAlerts];

        #ToDo: Several alerts are not check-able yet, so let's assume all is well
        $AlertChecks.AccountAlerts = @{$true="0"; $false="10"}[$false];
        $AlertChecks.MDMDeviceAlert = @{$true="0"; $false="10"}[$false];
        $AlertChecks.DataAlert = @{$true="0"; $false="10"}[$false];
    }

    # Update the scores in the main score table
    foreach ($key in $AlertChecks.Keys) {

        Set-Score $secureScoreTable $key $AlertChecks[$key]
    }

    return $AlertChecks;
}

Export-ModuleMember -Function Check-TenantAlerts

Function Get-UserToReviewData( $dataToReview)
{
    $msg = "Any of this activity for " + $dataToReview + " look weird or illicit? [Y/N]";
    $review = Read-Host -Prompt $msg

    $fAllIsGood = ($review -eq "N");

    if ($fAllIsGood) {
        Write-Log "Cool, looks like everything is square.";
    } else {
        Write-Log "Looks like you found an issue. Please visit the admin portal at https://portal.office.com to remediate the affected account.";
    } 

    return $fAllIsGood;
}

Function Check-AdminRoles( $tenantInfo, $secureScoreTable)
{
    Write-Log "Checking Admin Roles for this tenant." 2


    #Let's review the current admin group members
    $adminroleguids = Get-MsolRole | where { $_.Name.Contains("Admin")} | Select Name, ObjectId
    foreach ($adminRole in $adminroleguids)
        {
            $members= Get-MsolRoleMember -RoleObjectId $adminRole.ObjectId;

            if ($members.Length -gt 0) {
                foreach ($member in $members)
                {            
                    $msg = " Members of the Admin Group [" + $adminRole.Name + "]: " + $member.DisplayName
                    Write-Log $msg
                }
            } else {
                $msg = "    No Administrators found for the Admin Group [" + $adminRole.Name + "]: ";
                Write-Error $msg
            }
        }

    $fRoleActivityIsGood = Get-UserToReviewData( "Admin Roles");

    $AdminRoleChecks = @{};
    $AdminRoleChecks.RGChanges = @{$true="10"; $false="0"}[$fRoleActivityIsGood];
    $AdminRoleChecks.DelegatedAdmins = @{$true="5"; $false="0"}[$fRoleActivityIsGood];


    # Update the scores in the main score table
    foreach ($key in $AdminRoleChecks.Keys) {

        Set-Score $secureScoreTable $key $AdminRoleChecks[$key]
    }

    return $AdminRoleChecks;
}

Export-ModuleMember -Function Check-AdminRoles

Function Write-AuditReportsOut( $reportUri, $headerParams)
{
    $msg = "  Getting results from: """ + $reportUri + """";
    Write-Log $msg;

    $myReport = $null;

    Try {
        $myReport = (Invoke-WebRequest -Headers $headerParams -Uri $reportUri)
    } Catch {
        $ErrorMessage = $_.Exception.Message
        Write-Host "  Failed to obtain the reports."
        Write-Host "  ERROR: $ErrorMessage";
        $myReport = $null;
    }


    if ($myReport -ne $null) {
        $auditReport = (($myReport.Content | ConvertFrom-Json).value | select eventTime, actor, action, target)

        # ToDo: Prettify the report in the future
        $maxToShow = $auditReport.Length;

        if ($auditReport.Length -gt 5) {
            $msg = "  Only showing the first 5 records out of a maximum of " + $auditReport.Length + " audit records";
            Write-Log $msg;
            Write-Log "";
            $maxToShow = 5;
        }

        for($i = 0; $i -lt $maxToShow; $i++) {
            Write-Log $auditReport[$i];
            Write-Log "";
        }

        return $auditReport;
    }

    return $null;
}


Function Check-TenantReports( $tenantInfo, $secureScoreTable)
{
    Write-Log "Checking Tenant Wide Reports." 2
    $fReportsFound = $false;

    # -----------------------------------------------------------------------------
    #Pre-reqs for REST API calls. 
    $fAADLoaded = Load-ActiveDirectoryAuthenticationLibrary;
    Connect-AAD
    $header = $global:aadGPoShAuthResult.CreateAuthorizationHeader()
    $headerParams = @{"Authorization"=$header;"Content-Type"="application/json"}

    #Let's checkout out the Sign-Ins from Unknown Sources Report
    if ($global:aadGPoShAuthResult -ne $null) {

        $tenantdomain = $tenantInfo.inputDomainName
        
        Write-Log "1. Data from the AuditEvents report with datetime filter"
    
        $monthAgo = (Get-Date).AddDays(-30).ToString('MM-dd-yyyy')
        $reportUri = "https://graph.windows.net/$tenantdomain/reports/auditEvents?api-version=beta&$filter=eventTime gt $monthAgo";
        $myReport = Write-AuditReportsOut $reportUri $headerParams ;
        if ($myReport -ne $null) { $fReportsFound = $true; }
        
        Write-Log "2. Data from the Sign-Ins From Unknown Sources report"
        #ToDo: What if there is no report available?
        $reportUri = "https://graph.windows.net/$tenantdomain/reports/signInsFromUnknownSourcesEvents?api-version=beta";
        $myReport = Write-AuditReportsOut $reportUri $headerParams ;
        if ($myReport -ne $null) { $fReportsFound = $true; }

        Write-Log "3. Data from the Sign-Ins from Multiple Geographies report"
        #ToDo: What if there is no report available?
        $reportUri = "https://graph.windows.net/$tenantdomain/reports/signInsFromMultipleGeographiesEvents?api-version=beta";
        $myReport = Write-AuditReportsOut $reportUri $headerParams ;
        if ($myReport -ne $null) { $fReportsFound = $true; }

        Write-Log "4. Data from the Sign-Ins After Multiple Failures report"
        #ToDo: What if there is no report available?
        $reportUri = "https://graph.windows.net/$tenantdomain/reports/signInsAfterMultipleFailuresEvents?api-version=beta"
        $myReport = Write-AuditReportsOut $reportUri $headerParams ;
        if ($myReport -ne $null) { $fReportsFound = $true; }

        #ToDo: look at all the reports that are available ... and see what we can use further
    } else {
        Write-Host "ERROR: No Access Token was available. So we could not check signIns reports"
    }

    if ($fReportsFound) {
        $fActivityReviewIsGood = Get-UserToReviewData( "Tenant Reports");
    } else {
        $fActivityReviewIsGood = $true;
    }

    $TenantReportChecks = @{};
    $TenantReportChecks.ProvisionedAccounts = @{$true="5"; $false="0"}[$fActivityReviewIsGood];
    $TenantReportChecks.AccountChanges = @{$true="10"; $false="0"}[$fActivityReviewIsGood];
    $TenantReportChecks.DeviceSignIns = @{$true="10"; $false="0"}[$fActivityReviewIsGood];
    $TenantReportChecks.UnknownSignIns = @{$true="10"; $false="0"}[$fActivityReviewIsGood];
    $TenantReportChecks.GeoSignIns = @{$true="10"; $false="0"}[$fActivityReviewIsGood];
    $TenantReportChecks.FailedSignIns = @{$true="15"; $false="0"}[$fActivityReviewIsGood];

    # Update the scores in the main score table
    foreach ($key in $TenantReportChecks.Keys) {

        Set-Score $secureScoreTable $key $TenantReportChecks[$key]
    }

    return $TenantReportChecks;
}
Export-ModuleMember -Function Check-TenantReports

Function Check-TenantAuditLog( $tenantInfo, $AllUsers, $UserInboxRules, $UserDelegates, $secureScoreTable)
{
    Write-Log "Checking Various Audit Logs." 2

    # ToDo:  Get the internal AAD Audit APIs working
    Write-Log "1. Data for AAD SignIns"
    Write-Log "     Internal: AAD Signin Checks for illicit Logons are disabled till SearchAPIs are ready."

    $today = (Get-Date).ToString('MM-dd-yyyy')
    $weekAgo = (Get-Date).AddDays(-7).ToString('MM-dd-yyyy')

    #
    #Disabling illicit logon checks until search-unifiedauditlog or aad audit api's include this data
    #foreach ($User in $AllUsers) 
    #    { 
    #        $msg = "Checking Unified Audit Log for user: " + $User.UserPrincipalName;
    #        Write-Log $msg;
    #
    #       #ToDo: Search-UnifiedAuditLog is missing in my commandlet installation. Need to find it!
    #       $aadlogon = Search-UnifiedAuditLog -StartDate $weekAgo -EndDate $today -RecordType AzureActiveDirectoryAccountLogon -UserIds $User.UserPrincipalName;
    #       $aadlogon;
    #   }
    # $AADLogonsAreGood = Get-UserToReviewData( "AAD SignIns");
    #

    $AADLogonsAreGood = $true; 
    $TenantAuditLogChecks = @{};
    $TenantAuditLogChecks.AnomalousLogons = @{$true="10"; $false="0"}[$AADLogonsAreGood];

    Write-Log "2. Data for Non-Owner Mailbox Logons"

    #Disabling mailbox access by non-owner checks until search-unifiedauditlog or aad audit api's include this data...sheesh
    #Mailbox Access by Non-Owners
    #ToDo: Search-UnifiedAuditLog is missing in my commandlet installation. Need to find it!
    #$NonOwnerMBXLogons = Search-UnifiedAuditLog -StartDate $weekAgo -EndDate $today -RecordType ExchangeAdmin,ExchangeItem,ExchangeItemGroup
    #Write-Host $NonOwnerMBXLogons | Format-List
    # $fMailboxesAreGood = Get-UserToReviewData( "Non Owner Mailboxes");
    
    $fMailboxesAreGood = $true;
    if ($UserDelegates.Count -gt 0) {
        #Update this to show the count of mailbox delegates there are, then pop the report to see if there are illicit logons
        Write-Host $UserDelegates | Select *
        $fMailboxesAreGood = Get-UserToReviewData("Mailbox Delegates");
    } else {
        $fMailboxesAreGood = $true;
    }

    $TenantAuditLogChecks.NonOwnerAccess = @{$true="5"; $false="0"}[$fMailboxesAreGood];

    Write-Log "3. Data for Malware Detections"

    $MalwareDetections = Get-MailDetailMalwareReport -StartDate $weekAgo -EndDate $today
    if ($MalwareDetections.Length -gt 0) {
        Write-Host $MalwareDetections | Select *
        $fMalwareDetectionsActivityReview = Get-UserToReviewData("Malware");
    } else {
        $fMalwareDetectionsActivityReview = $true;
    }

    $TenantAuditLogChecks.MalwareDetections = @{$true="5"; $false="0"}[$fMalwareDetectionsActivityReview];

    #This has a bug. It is only showing forwarding rules for the tenant admin running the script. Need to compile a mega-blob of user mailbox data
    Write-Log "4. Data for Mailbox Forwarding Rules"
    if ($UserInboxRules.Count -gt 0) {
        Write-Host $UserInboxRules | Select *
        $fMBXForwardingActivityReview = Get-UserToReviewData("InboxForwardingRules");
    } else {
        $fMBXForwardingActivityReview = $true;
    }

    $TenantAuditLogChecks.MailForwardingRules = @{$true="5"; $false="0"}[$fMBXForwardingActivityReview];

    # Update the scores in the main score table
    foreach ($key in $TenantAuditLogChecks.Keys) {

        Set-Score $secureScoreTable $key $TenantAuditLogChecks[$key]
    }

    return $TenantAuditLogChecks;
}

Export-ModuleMember -Function Check-TenantAuditLog


Function Check-AllSecurityControls( $TenantInfo, $AdminCredential, $AllUsers, $UserInboxRules, $UserDelegates, $AllScoresTable) 
{
    Write-Log "Analyze SCORE and summarize" 2
    $AllScores=@{}
    $AllScores.TenantChecks = Check-TenantWidePolicies $TenantInfo $AllUsers $AllScoresTable
    $AllScores.DeviceChecks = Check-DevicePolicies $TenantInfo $AllScoresTable
    $AllScores.SharingChecks = Check-SharingPolicies $TenantInfo $AllScoresTable
    $AllScores.AdvancedChecks = Check-AdvancedPolicies $TenantInfo $AllScoresTable
    $AllScores.BehaviorChecks = Check-BehaviorPolicies $TenantInfo $AllUsers $UserInboxRules $UserDelegates $AllScoresTable
    $AllScores.AlertChecks= Check-TenantAlerts $TenantInfo $AllScoresTable
    $AllScores.AdminRoleChecks= Check-AdminRoles $TenantInfo $AllScoresTable

	$AllScores.SFBScores = Get-SFBScores $TenantInfo $AdminCredential $AllScoresTable
	$AllScores.SPOScores = Get-SPOScores $TenantInfo $AllScoresTable

    $AllScores.TenantAuditLogChecks = Check-TenantAuditLog $TenantInfo $AllUsers $UserInboxRules $UserDelegates $AllScoresTable
    $AllScores.TenantReportChecks = Check-TenantReports $TenantInfo $AllScoresTable

    #ToDo: Check ADFS Client Access Policy.

    # ToDo: if needed enable a quick signature dump for scores
    # Write-SummaryOfScores $AllScoresTable

    Write-Log "All Checks for Configuration and Reports completed."
    return $AllScores;
}

Export-ModuleMember  -Function Check-AllSecurityControls;

Function Get-FinalSecurityScore( $tenantInfo, $AllScoresTable)
{
    Write-Log "Format the output data" 2

    $secureScoreTable = $AllScoresTable |  Select Type, Class, Enablement, Workload, ReferenceID, Control, Baseline, Score, Action, ActionURL

    $timeNow = Get-Date
    Write-Host "Calculate final score for the tenant.";
    $scoreSummary=@{}

    foreach ($control in $secureScoreTable)
    {
        #Each of the subclass aggregates
        if ($control.Class -eq "Account") { $scoreSummary.accountscore += $control.Score; }
        if ($control.Class -eq "Device") { $scoreSummary.devicescore += $control.Score; }
        if ($control.Class -eq "Data") { $scoreSummary.datascore += $control.Score; }

        #The aggregate        
        $scoreSummary.score += $control.Score
        $scoreSummary.baseline += $control.Baseline
    }

    #ToDo: Provide a summary about the domain checked for and details on what rules took away the points in the score.
    #ToDo: also include a summary of the user-provided-inputs to questions to do 'what-if' checks on Y/N provided.
    Write-Host
    
    Write-Host "Congrats, your overall score for " -NoNewline; write-host $timeNow -NoNewline -ForegroundColor Green; write-host " was " -NoNewline; 
    Write-Host $scoreSummary.score -NoNewline -ForegroundColor Green; 
    Write-Host " of a possible " -nonewline; Write-host $scoreSummary.baseline -ForegroundColor Green 

    Write-Host "  Account score : " -NoNewline; Write-Host $scoreSummary.accountscore -ForegroundColor Green
    Write-Host "  Device score  : " -NoNewline; Write-Host $scoreSummary.devicescore -ForegroundColor Green
    Write-Host "  Data score    : " -NoNewline; Write-Host $scoreSummary.datascore -ForegroundColor Green
    Write-Host "  Total Score   : " -NoNewline; Write-Host $scoreSummary.score
    Write-Host "  Baseline Max  : " -NoNewline; Write-Host $scoreSummary.baseline -ForegroundColor Green
    Write-Host

    # normalize date/time of creation to be suitable for UTC usage
    $utcTime = $timeNow.ToUniversalTime()
    $createdTime = $utcTime.ToString("MM/dd/yyyy", [System.Globalization.CultureInfo]::InvariantCulture) + " " + $utcTime.ToString("T", [System.Globalization.CultureInfo]::InvariantCulture) + " GMT";

    $summary = @{};
    $summary.creationID = [System.Guid]::NewGuid().toString();
    $summary.createdDate = $createdTime;
    $summary.tenantID =  $tenantInfo.TenantGUID;
    $summary.tenantAdmin = $tenantInfo.AdminName;
    $summary.tenantDomain= $tenantInfo.inputDomainName;
    $summary.score = $scoreSummary.score;
    $summary.baseline= $scoreSummary.baseline;
    
    $dataToOutput = @{};
    $dataToOutput.version = $globalConfig.ScoreVersion;
    $dataToOutput.summary = $summary;
    $dataToOutput.detail = $secureScoreTable;

    return $dataToOutput;
}

Export-ModuleMember -Function Get-FinalSecurityScore


Function Save-ScoreDataToFile( $tenantInfo, $dataToOutput) 
{
    # use -Encoding "Default" to ensure there are no Byte-Order-Marks inserted into the file
    $dataInJson = $dataToOutput | ConvertTo-Json

    # Generate the output we are looking for .... 
    $today = (Get-Date).ToString('MM-dd-yyyy')
    $outputFilePrefix = "$today" + "-" + $tenantInfo.TenantGUID+ "-SecureScore"
    $jsonOutputFile = $outputFilePrefix+".json";

    $msg = " Results are stored in JSON file: " + $jsonOutputFile + ". Created at: " + $dataToOutput.summary.createdDate;
    Write-Log $msg;
    $dataInJson |Out-File -Encoding "Default" $jsonOutputFile;

    return $dataInJson;
}

Export-ModuleMember -Function Save-ScoreDataToFile

Function Invoke-RestMethodCall( $postUri, $token, $bodyInJson = $null) 
{
    $client = New-Object System.Net.WebClient;
    $client.Headers.Add("Content-Type", "application/json");
    $client.Headers.Add("Accept", "application/json");
    if ($token -ne $null) {
      $authHeader = $token.AccessTokenType + " " + $token.AccessToken; 
      $client.Headers.Add("Authorization", $authHeader);
    }

    Write-Host "---------------------------------------------------------"
    Write-Host " Posting collected SecurityScore to " $postUri
    
    $var = $client.UploadData($postUri, [System.Text.Encoding]::ASCII.GetBytes($bodyInJson));
    $client.Dispose();

    Write-Host
    $resultsInJson = [System.Text.Encoding]::ASCII.GetString($var) | ConvertTo-Json;
    Write-Host " Response: " $resultsInJson;
    Write-Host
}

Export-ModuleMember -Function Invoke-RestMethodCall

Function Save-ScoreToScorerService( $saveSecureScoreToUri, $userCredential, $dataInJson)
{
    Write-Log "Great! Now we will upload your scores to the service for further analysis." 2
    Write-Log "Please log in one more time with admin credentials to do secure upload. (we will optimize this in the future)"

    # Get these settings from the global configuration
    $config = @{
        authority = "https://login.windows.net/common";
        redirectUri = "urn:ietf:wg:oauth:2.0:oob";
        resourceAppIdURI = $globalConfig.O365SecureScoreAppIdURI;
        clientID = $globalConfig.O365SecureScoreCollectorClientID;
    }

    $token = Get-TokenResult $config
    Invoke-RestMethodCall $saveSecureScoreToUri $token $dataInJson

    return;
}

Export-ModuleMember -Function Save-ScoreToScorerService


# -- For debugging .. dump the scores table
Function Write-ScoreTableDump()
{
    $ScoreTypes = @("TenantChecks", "DeviceChecks", "SharingChecks", "AdvancedChecks", 
        "BehaviorChecks", "AlertChecks", "AdminRoleChecks");
    foreach($x in $ScoreTypes) {
        $msg = "Score: $x"; Write-Log $msg 2;
        $AllScores[$x];
    }

    Write-SummaryOfScores $AllScoresTable
}

Export-ModuleMember -Function Write-ScoreTableDump

Function Get-SPOScores( $tenantInfo, $secureScoreTable)
{
   Write-Log "Connecting to Sharepoint Online Powershell Service" 2
   
    Try
    {
        #First, let's construct the SPOAdmin URL from the user's admin email address
        $SPOAdminURLBase = $AdminCredential.UserName.Split("@")[1] | Select-String -Pattern "([^.]+)" | Select-Object -Expand matches | Select-Object -Expand Value
        $SPOAdminURL = "https://" + $SPOAdminURLBase + "-admin.sharepoint.com"

        #Then, let's connect to the service!
        Connect-SPOService -Url $SPOAdminURL -Credential $AdminCredential
    }
    Catch
    {
        Write-Log "  No SharePoint Online service set up for this account"
        $ServiceInfo.Set_Item("SPO", "False")        

    }


    if ($ServiceInfo.SPO -eq "False")
    {
        Write-Host "SharePoint Online is not enabled for this tenancy, so we cannot run checks."
    }
    else
    {
        Write-Log("Loading SharePoint Online related scores")
        $SPOScores = @{};
        #ToDo: SPO does not work if there is no SPO Tenant configured
        #what is the SPO Tenant Sharing Policy? Three Possible cases: ExternalUserAndGuestSharing, ExternalUserSharingOnly, and Disabled
        $SPOSharingPolicy = Get-SPOTenant | select SharingCapability
        if ( $SPOSharingPolicy -eq $null) {

            Write-Error "  Unable to find Sharepoint Sharing Policies."
        } else {

            #check to see if they are sharing externally
            if ($SPOSharingPolicy.SharingCapability -notcontains "ExternalUserSharingOnly")  { $SPOScores.ExternalAccess = "10"; } else {  $SPOScores.ExternalAccess = "0"; }

            #check to see fi they are sharing anonymously
            if ($SPOSharingPolicy.SharingCapability -notcontains "ExternalUserAndGuestSharing")  { $SPOScores.AnonymousAccess = "10"; } else {  $SPOScores.AnonymousAccess = "0"; }
        }
    }

    # Update the scores in the main score table
    foreach ($key in $SPOScores.Keys) {

        Set-Score $secureScoreTable $key $SPOScores[$key]
    }

    return $SPOScores;
}
Export-ModuleMember -Function Get-SPOScores;

# SFB = Skype For Business
Function Get-SFBScores( $tenantInfo, $AdminCredential, $secureScoreTable)
{
    $SFBScores= @{};

   Write-Log "Connecting to Skype for Business Powershell Service" 2

    Try
    {
        $SFBsession = New-CsOnlineSession -Credential $AdminCredential -Verbose
        if ($null -ne $SFBsession) { 
            Write-Log "  Loaded Skype Online Session. Let us import the commands."
            Import-PSSession $SFBsession
        } else {
            Write-Log "  No Skype for Business set up for this account"
            $ServiceInfo.Set_Item("SFB", "False")
        }
    }
    Catch
    {
        $ErrorMessage = $_.Exception.Message
        Write-Host " Failed to connect to Skype for Business Powershell endpoints."
        Write-Host " ERROR: $ErrorMessage";
        $ServiceInfo.Set_Item("SFB", "False")
    }

    if ($ServiceInfo.SFB -eq "False")
    {
        Write-Host "Skype for Business is not enabled for this tenancy, so we cannot run checks."
    }
    else
    {
        Write-Log("Loading Skype For Business related scores")
  
        #ToDo: SkypeForBusiness does not work if there is no SFB Tenant configured
        #What is the Skype For Business sharing policy?
        $SFBSharingPolicy = Get-CsExternalAccessPolicy | Where-Object {($_.Identity -eq "Global")}
        if ( $SFBSharingPolicy -eq $null) {

            Write-Error "  Unable to find Skype For Business Sharing Policies."
        } else {

            #Check if they allow outside access?
            if ($SFBSharingPolicy.EnableOutsideAccess -ne "True")  { $SFBScores.ExternalSFB = "5"; } else {  $SFBScores.ExternalSFB = "0"; }
        }
    }

    # Update the scores in the main score table
    foreach ($key in $SFBScores.Keys) {

        Set-Score $secureScoreTable $key $SFBScores[$key]
    }

    return $SFBScores;
}

Export-ModuleMember -Function Get-SFBScores;


# --------------------------------------------------------------------------------------------------------------

Function DoDownloadAndInstallExternals( $msg, $uri, $download)
{
    Write-Host $msg;
    Write-Host "Launching Instructions at " $uri;
    start $uri;
    Write-Host "  Starting the download from " $uri;
    start $download;
}

Export-ModuleMember -Function DoDownloadAndInstallExternals;


Function CheckAndLoadModule( $moduleName, $msg, $instructionUri, $downloadUri)
{
    $modulePresent = $true; # assume success

    Write-Host "  Checking for Module " $moduleName

    $module = Get-Module -ListAvailable | Where-Object {$_.Name -eq $moduleName};
    if ($null -eq $module) {
        Write-Host "You don't appear to have Skype for Business Powershell Modules installed on this computer. Here are the instructions and download to install. Install, then re-run the collector.";

        DoDownloadAndInstallExternals -msg $msg -uri $instructionUri -download $downloadUri
        $modulePresent = $false;
    }
    else
    {
        Write-Host "    Module is present. Loading module : " $moduleName
        try
        {
            $env:PSModulePath = [System.Environment]::GetEnvironmentVariable("PSModulePath","Machine")
            Import-Module $moduleName -DisableNameChecking
            Write-Host "    Module loading is complete now. "
        }
        catch
        {
            $ErrorMessage = $_.Exception.Message
            Write-Host " Failed to import the module " $moduleName;
            Write-Host " ERROR: $ErrorMessage";
            $modulePresent = $false;
        }
    }

    return $modulePresent;
}

function Check-Presetup ( $AdminCredential) {

    $setupBlocked = $false

    #Check Azure AD
    if (-not(Get-Module -ListAvailable | Where-Object {$_.Name -eq "MSOnline"}))
    {
        Write-Log ("You don't appear to have Azure Active Directory installed on this computer. Here are the instructions and downloads to install. Install, then re-run the collector.") 2 
        DoDownloadAndInstallExternals -msg "Install Microsoft Online Services Sign-In Assistant for IT PROs" -uri "https://msdn.microsoft.com/en-us/library/azure/jj151815.aspx#bkmk_installmodule" -download "http://go.microsoft.com/fwlink/?LinkID=286152"
        DoDownloadAndInstallExternals -msg "Install Windows Azure Active Directory Module for Powershell" -uri "https://msdn.microsoft.com/en-us/library/azure/jj151815.aspx#bkmk_installmodule" -download "http://go.microsoft.com/fwlink/p/?linkid=236297"
        $setupBlocked = $true
    }
    else
    {
        Write-Log("Checking Azure Active Directory module.") 2
        try { Import-Module MSOnline; Write-Log ("Looking good!"); } catch { $setupBlocked = $true }
    }

    #Check Azure
    if(-not(Get-Module -ListAvailable | Where-Object {$_.Name -eq "Azure"}))
    {
        Write-Log ("You don't appear to have Azure Powershell Modules installed on this computer. Here are the instructions and download to install. Install, then re-run the collector.") 2 
        DoDownloadAndInstallExternals -msg "Install Azure Powershell modules." -uri "https://azure.microsoft.com/en-us/documentation/articles/powershell-install-configure/" -download "http://go.microsoft.com/fwlink/p/?linkid=320376&clcid=0x409"
        $setupBlocked = $true
    }
    else
    {
        try 
        {
        	$azurePSRoot="C:\Program Files (x86)\Microsoft SDKs\Azure\Powershell"
            $azureServiceManagementModule= $azurePSRoot + "\ServiceManagement\Azure\Azure.psd1"
            Write-Log("Checking Azure Service Management module: "+$azureServiceManagementModule) 2
            Write-Log ("Looking good!")
            Import-Module $azureServiceManagementModule

        }
        catch
        {
            $setupBlocked = $true
        }
    }

    #Check AADRM
    if(-not(Get-Module -ListAvailable | Where-Object {$_.Name -eq "AADRM"})) 
    {
        Write-Log ("You don't appear to have AAD Rights Management installed on this computer. Here are the instructions and download to install. Install, then re-run the collector.") 2 
        DoDownloadAndInstallExternals -msg "Install Azure Rights Management" -uri "https://msdn.microsoft.com/library/azure/dn629398.aspx" -download "https://go.microsoft.com/fwlink/?LinkId=257721"
        $setupBlocked = $true
    }
    else
    {
        Write-Log("Checking AAD Rights Management module.") 2
        try { Import-Module aadrm; Write-Log ("Looking good!"); } catch { $setupBlocked = $true }

    }

    $sfbModulePresent = CheckAndLoadModule "SkypeOnlineConnector" -msg "Install Skype for Business commandlets" -instructionUri "https://technet.microsoft.com/en-us/library/dn362831(v=ocs.15).aspx" -downloadUri "http://go.microsoft.com/fwlink/?LinkId=294688"
    $spoModulePresent = CheckAndLoadModule "Microsoft.Online.SharePoint.Powershell" -msg "Install Sharepoint Online commandlets" -instructionUri "https://technet.microsoft.com/en-us/library/fp161372.aspx" -downloadUri "http://www.microsoft.com/en-us/download/details.aspx?id=35588";

    if (-not($sfbModulePresent ) -or -not($spoModulePresent)) {
        $setupBlocked = $true;
    }

    if ($setupBlocked -eq $true)
    {
        Write-Log ("Something with your configuration is amiss, and your Secure Score collection will likely fail. Please review the logs above and correct any issues with your local client configuration.");
        break;
    }
}

Export-ModuleMember -Function Check-Presetup;
